multer2=np.load(directory + "S_42.npy")
multer3=np.load(directory + "S_43.npy")
multer4=np.load(directory + "S_44.npy")
################directory + ############
multer5=np.load(directory + "S_51.npy")
multer6=np.load(directory + "S_52.npy")
multer7=np.load(directory + "S_53.npy")
multer8=np.load(directory + "S_54.npy")
################directory + ############
multer9=np.load(directory + "S_61.npy")
multer10=np.load(directory +"S_62.npy")
multer11=np.load(directory +"S_63.npy")
multer12=np.load(directory +"S_64.npy")
#################directory +###########
multer13=np.load(directory +"S_71.npy")
multer14=np.load(directory +"S_72.npy")
multer15=np.load(directory +"S_73.npy")
multer16=np.load(directory +"S_74.npy")
#################directory +###########
multer17=np.load(directory +"S_81.npy")
multer18=np.load(directory +"S_82.npy")
multer19=np.load(directory +"S_83.npy")
multer20=np.load(directory +"S_84.npy")